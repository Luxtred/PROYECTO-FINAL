
package robopato;

import java.util.Scanner;
import static robopato.Gamer.gamer;
import static robopato.Hardware.Hardware;
import static robopato.Software.software;

/**
 *
 * @author Emmanuel Landero
 */




public class Menu {

  
     
 public static void main(String[] args) {
     
     menu ();    
   
    }
    public static void menu() {
        
    
    
        Scanner scanner = new Scanner (System.in);
        
        System.out.println("""
                           Tiendas RoboPato
                           Buen dia Sr.Fulano
                           
                           1. Hardware
                           2. Software
                           3. Gamer
                           
                           4. Salir""");
        int opcion = scanner.nextInt();
        
        switch (opcion) {
            case 1 -> Hardware();
            
            
            case 2 -> software();
            
             
            case 3 -> gamer();
            
                
            case 4 -> salida();
                
            default -> System.out.println("ELIJE UNA OPCION");
                
        }
        
       
   
    }
    private static void salida() {
        System.out.println("Gracias, vuelva pronto :) ");
    }
   
}
