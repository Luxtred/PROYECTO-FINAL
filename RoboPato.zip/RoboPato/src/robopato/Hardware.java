package robopato;

import java.util.Scanner;
import static robopato.Menu.menu;

/**
*
*@author Aldo Francisco
*/


public class Hardware {

    public static void main(String[] args) {
        Hardware();
    }

    public static void Hardware() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("""
                               Menu de la aplicaci\u00f3n
                               
                               1. Teclado
                               2. Mouse
                               3. Salir
                               Elija una Opci\u00f3n""");
        int opcion = scanner.nextInt();
        switch (opcion) {
            case 1 ->
                teclado();
            case 2 ->
                mouse();
            case 3 ->
                Salir();
            default ->
                System.out.println("Elija un opción valida");
        }
    }

    private static void teclado() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("""
                           1. Alambrico
                           2. Inalambrico
                           3. Salir""");
        int op = scanner.nextInt();
        if (op == 1) {
            int pre = 800;
            int total;
            System.out.println("Ingresa la cantidad deseada");
            int cant = scanner.nextInt();

            total = pre * cant;
            System.out.println("El total a pagar es: " + total);

            System.out.println("""
                               \u00bfDesea hacer otra compra?
                               1. Si
                               2. Salir""");
            int sn = scanner.nextInt();
            switch (sn) {
                case 1 -> teclado();
                case 2 -> Hardware();
                case 3 -> Hardware();
                default -> {
                }
            }

        }
        if (op == 2) {
            
            int pre = 250;
            int total;
            System.out.println("Ingresa la cantidad deseada");
            int cant = scanner.nextInt();

            total = pre * cant;
            System.out.println("El total a pagar es: " + total);
            
            
            System.out.println("""
                               \u00bfDesea hacer otra compra?
                               1. Si
                               2. Salir""");
            int sn = scanner.nextInt();
            switch (sn) {
                case 1 -> teclado();
                case 2 -> Hardware();
              
                default -> {
                    System.out.println("Error, REINICIANDO");
                    error();
                }
            }
        }
    }

    



    private static void mouse() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("""
                           1. Alambrico
                           2. Inalambrico
                           3. Salir""");
        int op = scanner.nextInt();
        if (op == 1) {
            int pre = 130;
            int total;
            System.out.println("Ingresa la cantidad deseada");
            int cant = scanner.nextInt();

            total = pre * cant;
            System.out.println("El total a pagar es: " + total);

            System.out.println("""
                               \u00bfDesea hacer otra compra?
                               1. Si
                               2. Salir""");
            int sn = scanner.nextInt();
            switch (sn) {
                case 1 -> teclado();
                case 2 -> Hardware();
                case 3 -> Hardware();
                default -> {
                }
            }

        }
        if (op == 2) {
            int pre = 250;
            int total;
            System.out.println("Ingresa la cantidad deseada");
            int cant = scanner.nextInt();

            total = pre * cant;
            System.out.println("El total a pagar es: " + total);

            System.out.println("""
                               \u00bfDesea hacer otra compra?
                               1. Si
                               2. Salir""");
            int sn = scanner.nextInt();
            switch (sn) {
                case 1 -> teclado();
                case 2 -> Hardware();
                
                default -> {
                }
            }
        }
    }


    private static void Salir() {
        menu();
    
   }

    private static void error() {
    Hardware();    
    }

   
    
}
 
