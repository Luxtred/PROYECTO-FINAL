
package robopato;

import java.util.Scanner;
import static robopato.Menu.menu;

/**
 *
 * @author Emmanuel Landero 
 */
public class Software{
    
    
    
 public static void software(){
     Scanner scanner = new Scanner(System.in);
     System.out.println("¿Qué desea?");
     
     System.out.println("""
                        1. Sistema operativos
                        2. Paqueteria
                        3. Regresar al menu principal
                        """);
     int opcion = scanner.nextInt();

     switch (opcion) {
         case 1 -> sisOp();
             
         case 2 -> paquet();
         
         case 3 -> menu();   
                 
         
         
         default -> System.out.println("ESCOJA UNA OPCION");
     }
}

    private static void sisOp() {
        Scanner op = new Scanner(System.in);
        
        
        System.out.println("""
                           \u00bfQue sistema operativo desea?
                           1. Windows
                           2. iOS
                           
                           
                           3. Regresar
                           4. Salir""");
       int opc = op.nextInt();
        
        switch (opc){
            case 1 -> windows();
               
            case 2 -> iOS();
                
            case 3 -> regresar();
               
            case 4 -> salir();
                
            default -> System.out.println("ESCOJE UNA OPCION");
        }
    }
    //Menu de sistemas operativos
        private static void windows(){
            Scanner op = new Scanner (System.in);
            System.out.println("""
                               Escoja una version
                                1. Windows 7
                                2. Windows 10
                                3. Windows 11
                                4. Regresar
                                5. Salir""");
            int opw = op.nextInt();
            
     switch (opw) {
         case 1 -> {
             System.out.println("Descontinuado");
             System.out.println("Escoja otra opcion");
             System.out.println("1. Salir");
             int opci = op.nextInt();
             switch (opci){
                 case 1 -> windows();
                 default-> {
                     System.out.println("ESCOJE UNA OPCION");
                     
                 }
             }
         }
         case 2 ->              {
                 Scanner scanner = new Scanner (System.in);
                 int l;
                 int p = 500;
                 System.out.println("Cuantas licencias desea?");
                 l = scanner.nextInt();
                 int total = p*l;
                 System.out.println("El total a pagar es de"+total);
                 System.out.println("""
                                                     Desea hacer otra transaccion?
                                                      1. Si
                                                      2. No""");
                 int o = scanner.nextInt();
                 if(o == 1){
                     windows();
                 }else if (o == 2){
                     sisOp();
                 }             }
         case 3 ->              {
                 Scanner scanner = new Scanner (System.in);
                 int l;
                 int p = 650;
                 System.out.println("Gratis en la pagina oficial de Microsoft?");
                 l = scanner.nextInt();
                 System.out.println("""
                                                     Desea hacer otra transaccion?
                                                      1. Si
                                                      2. No""");
                 int o = scanner.nextInt();
                 if(o == 1){
                     windows();
                 }else if (o == 2){
                     sisOp();
                 }             }
         
         case 4 -> sisOp();
             
         case 5 -> salir();
         default -> {
         }
     }
        }
        
    private static void iOS(){
        Scanner opIO = new Scanner (System.in);
        
        System.out.println("""
                           Para que dispositivo lo desea
                           1. iPhone
                           2. iPad """);
        int opiOS = opIO.nextInt();
        
        if (opiOS == 1){
            int cos = 1095;
            
            System.out.println("""
                               Ingrese la cantidad deseada
                                Costo de la licencia de $1905""");
            
            int opL= opIO. nextInt ();
            
            int total = cos*opL;
            
            System.out.println("El total a pagar es de: "+total);
            
            System.out.println("""
                               Desea hacer otra transaccion?
                               1. Si
                               2. NO""");
            int opS = opIO.nextInt();
            switch (opS) {
                case 1 -> iOS();
                case 2 -> sisOp();
                default -> {
                    System.out.println("Escoja una opcion");
                    iOS();
                }
            }
            
            
       
            
        }
        
    }
    
    
    private static void paquet() {
    Scanner pak = new Scanner (System.in);
    
    int opPa;
        System.out.println("""
                           Escoja una opcion
                           1. Office 365
                           2. Antivirus
                           3. Photoshop
                           4. Regresar""");
        opPa= pak.nextInt();
        
        switch (opPa) {
            case 1 -> System.out.println("Agotada");
            case 2 -> System.out.println("Incluido en el sistema de windows 10 y 11");
            case 3 -> {
                Scanner liP = new Scanner (System.in);
                System.out.println("""
                                   Limite de licencias: 10
                                    costs de $500""");
                int clP = liP.nextInt();
                
                if(clP >=11){
                    System.out.println("Limite excedido");
                }else{
                    int lp = 500;
                    
                    int t = lp*clP;
                    
                    System.out.println("El costo es de "+t);
                }
         }
                
            case 4 -> software();
                
                
            default -> {
                System.out.println("INGRESE UN TERMINO VALIDO");
                paquet();
         }
        }
    
    
        
        
        
    }

    private static void regresar(){
        software();
    }

    

    private static void salir() {
        menu();
    }

    
}
