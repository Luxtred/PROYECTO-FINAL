/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package robopato;

/**
 *
 * @author manit
 */
public class PRINCIPAL {
       private int hardware, software, gamer, salir;

    public PRINCIPAL() {
    }

    public PRINCIPAL(int hardware, int software, int gamer, int salir) {
        this.hardware = hardware;
        this.software = software;
        this.gamer = gamer;
        this.salir = salir;
    }

    @Override
    public String toString() {
        return "PRINCIPAL{" + "hardware=" + hardware + ", software=" + software + ", gamer=" + gamer + ", salir=" + salir + '}';
    }

    public int getHardware() {
        return hardware;
    }

    public void setHardware(int hardware) {
        this.hardware = hardware;
    }

    public int getSoftware() {
        return software;
    }

    public void setSoftware(int software) {
        this.software = software;
    }

    public int getGamer() {
        return gamer;
    }

    public void setGamer(int gamer) {
        this.gamer = gamer;
    }

    public int getSalir() {
        return salir;
    }

    public void setSalir(int salir) {
        this.salir = salir;
    }
       
       
}
