package robopato;

import java.util.Scanner;
import static robopato.Menu.menu;

/**
*
*@author Wenceslao Alexander
*/


public class Gamer {

    public static void main(String[] args) {
      
    
        
        
    }
    public static void gamer() {
        
    
        Scanner scanner = new Scanner (System.in);
        


System.out.print("""
                 Juegos Buenos, Bonitos y Baratos
                 1. Cat Bros Precio: $350
                 
                 2. El pibe rapero Precio: $250
                 
                 3. Regresar
                 Elija un juego: """);

        int juego=scanner.nextByte();



        switch (juego) {
            case 1 -> {
                int precio;
                int cantidad;
                System.out.println("*---------------------*");
                
                System.out.println("Cat Bros");
                
                System.out.print("Ingrese la cantidad: ");
                cantidad = scanner.nextInt();
                precio=350*cantidad;
                
                System.out.println("La cantidad es de: " + cantidad);
                System.out.println("Precio a pagar $" + precio);
                System.out.println("*---------------------*");
                
                System.out.println("Desea hacer otra compra?"
                        + "1. Si"
                        + "2. No");
                int op= scanner.nextInt();
                if(op == 1){
                    gamer();
                    
                }else if(op == 2){
                    menu();
                }
            }
            case 2 -> {
                System.out.println("El pibe rapero de cabello azul");
                System.out.print("Ingrese la cantidad: ");
                int cantidad = scanner.nextInt();
                int precio = 350*cantidad;
                System.out.println("La cantidad es de: " + cantidad);
                System.out.println("Precio a pagar $" + precio);
                System.out.println("*---------------------*");
                System.out.println("Desea hacer otra compra?"
                        + "1. Si"
                        + "2. No");
                int opc= scanner.nextInt();
                if(opc == 1){
                    gamer();
                    
                }else if(opc == 2){
                    menu();
                }
            }
        
            case 3 -> menu();
                
            default -> {
                System.out.println("INGRESE UNA OPCION VALIDA");
                gamer();
            }
        }

       }
}

